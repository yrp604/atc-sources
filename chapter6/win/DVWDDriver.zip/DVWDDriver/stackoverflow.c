#include <ntifs.h>
#include <ntstrsafe.h>
#include "dvwd.h"

NTSTATUS __declspec(dllexport) TriggerOverflow(UCHAR *stream, UINT32 len);
static int ExceptionFilter();


#pragma alloc_text(PAGE, DvwdHandleIoctlStackOverflow) 
#pragma alloc_text(PAGE, TriggerOverflow)
#pragma alloc_text(PAGE, ExceptionFilter)


#pragma auto_inline(off)

static int ExceptionFilter()
{
  PAGED_CODE();
  return EXCEPTION_EXECUTE_HANDLER;
}


#define LOCAL_BUFF 64
NTSTATUS __declspec(dllexport) TriggerOverflow(UCHAR *stream, UINT32 len)
{
  char buf[LOCAL_BUFF];
  NTSTATUS NtStatus = STATUS_SUCCESS;	

  PAGED_CODE();	 
  __try 
  {
    DbgPrint("[-] Probing Userspace Buffer\r\n");
    ProbeForRead(stream, len, TYPE_ALIGNMENT(char));
    DbgPrint("[-] Copying %d bytes from userland\r\n", len);
    RtlCopyMemory(buf, stream, len);
    DbgPrint("[-] Copied: %d bytes, first byte: %c\r\n", len, buf[0]);
  } 
  __except(ExceptionFilter())
  {
    NtStatus = GetExceptionCode();
    DbgPrint("[!!] Exception Triggered: Handler body: Exception Code: %d\\r\n", NtStatus);   
  }
  return NtStatus;                                      
}  


NTSTATUS __declspec(dllexport) DvwdHandleIoctlStackOverflow(PIRP Irp, PIO_STACK_LOCATION pIoStackIrp) 
{ 
  PCHAR pInputBuffer;
  UINT32 pInputLen;
  NTSTATUS NtStatus = STATUS_UNSUCCESSFUL;

  PAGED_CODE();
  pInputBuffer = pIoStackIrp->Parameters.DeviceIoControl.Type3InputBuffer;
  pInputLen    = pIoStackIrp->Parameters.DeviceIoControl.InputBufferLength;

  if(pInputBuffer)
    NtStatus = TriggerOverflow(pInputBuffer, pInputLen);

  return NtStatus;
}


#pragma auto_inline()


