#include <ntifs.h>
#include <ntstrsafe.h>
#include "dvwd.h"



NTSTATUS     DvwdHandleIoctlOverwrite(PIRP Irp, PIO_STACK_LOCATION pIoStackIrp);
NTSTATUS     TriggerOverwrite(UCHAR *stream);
VOID         GetSavedData(PARBITRARY_OVERWRITE_STRUCT overwriteStruct);

NTSTATUS     DvwdHandleIoctlStore(PIRP Irp, PIO_STACK_LOCATION pIoStackIrp);
NTSTATUS     TriggerStore(UCHAR *stream);
VOID         SetSavedData(PARBITRARY_OVERWRITE_STRUCT overwriteStruct);

static       int ExceptionFilter();


#pragma alloc_text(PAGE, DvwdHandleIoctlOverwrite) 
#pragma alloc_text(PAGE, TriggerOverwrite)
#pragma alloc_text(PAGE, GetSavedData)
#pragma alloc_text(PAGE, DvwdHandleIoctlStore)
#pragma alloc_text(PAGE, TriggerStore)
#pragma alloc_text(PAGE, SetSavedData)
#pragma alloc_text(PAGE, ExceptionFilter)

static int ExceptionFilter()
{
  PAGED_CODE();
  return EXCEPTION_EXECUTE_HANDLER;
}


#define GLOBAL_SIZE_MAX 0x100

UCHAR GlobalBuffer[GLOBAL_SIZE_MAX];
ARBITRARY_OVERWRITE_STRUCT GlobalOverwriteStruct = {&GlobalBuffer, 0};



/* DVWD_OVERWRITE Handler */

VOID GetSavedData(PARBITRARY_OVERWRITE_STRUCT overwriteStruct)
{
  ULONG size = overwriteStruct->Size;
  PAGED_CODE();

  if(size > GlobalOverwriteStruct.Size)
    size = GlobalOverwriteStruct.Size;

  RtlCopyMemory(overwriteStruct->StorePtr, GlobalOverwriteStruct.StorePtr, size);
}


NTSTATUS TriggerOverwrite(UCHAR *stream)
{
  ARBITRARY_OVERWRITE_STRUCT overwriteStruct;
  NTSTATUS NtStatus = STATUS_SUCCESS;	

  PAGED_CODE();
  DbgPrint("[-] TriggerOverwrite function\r\n");
	 
  __try 
  {
    DbgPrint("[-] Zeroing Local Buffer\r\n");
    RtlZeroMemory(&overwriteStruct, sizeof(ARBITRARY_OVERWRITE_STRUCT));
	
    DbgPrint("[-] Copying the ARBITRARY_OVERWRITE_STRUCT from userland\r\n");
		ProbeForRead(stream, sizeof(ARBITRARY_OVERWRITE_STRUCT), TYPE_ALIGNMENT(char));
    RtlCopyMemory(&overwriteStruct, stream, sizeof(ARBITRARY_OVERWRITE_STRUCT));

    GetSavedData(&overwriteStruct);
  } 
  __except(ExceptionFilter())
  {
    NtStatus = GetExceptionCode();
    DbgPrint("[!!] Exception Triggered: Handler body: Exception Code: %d\r\n", NtStatus);   
  }
  
  return NtStatus;                                      
}  


NTSTATUS     DvwdHandleIoctlOverwrite(PIRP Irp, PIO_STACK_LOCATION pIoStackIrp)
{
  PCHAR pInputBuffer;
  UINT32 pInputLen;
  NTSTATUS NtStatus = STATUS_UNSUCCESSFUL;

  PAGED_CODE();
  pInputBuffer = pIoStackIrp->Parameters.DeviceIoControl.Type3InputBuffer;
  if(pInputBuffer)
    NtStatus = TriggerOverwrite(pInputBuffer);

  return NtStatus;
}








/* DVWD_STORE Handler */

VOID SetSavedData(PARBITRARY_OVERWRITE_STRUCT overwriteStruct)
{
  ULONG size = overwriteStruct->Size;

  PAGED_CODE();
  if(size > GLOBAL_SIZE_MAX)
    size = GLOBAL_SIZE_MAX;

  ProbeForRead(overwriteStruct->StorePtr, size, TYPE_ALIGNMENT(char));
  RtlCopyMemory(GlobalOverwriteStruct.StorePtr, overwriteStruct->StorePtr, size);
  GlobalOverwriteStruct.Size = size;
}



NTSTATUS TriggerStore(UCHAR *stream)
{
  ARBITRARY_OVERWRITE_STRUCT overwriteStruct;
  NTSTATUS NtStatus = STATUS_SUCCESS;	

  PAGED_CODE();
  DbgPrint("[-] TriggerStore function\r\n");
	 
  __try 
  {
    DbgPrint("[-] Zeroing Local Buffer\r\n");
    RtlZeroMemory(&overwriteStruct, sizeof(ARBITRARY_OVERWRITE_STRUCT));
		
    DbgPrint("[-] Copying the ARBITRARY_OVERWRITE_STRUCT from userland\r\n");
    ProbeForRead(stream, sizeof(ARBITRARY_OVERWRITE_STRUCT), TYPE_ALIGNMENT(char));
    RtlCopyMemory(&overwriteStruct, stream, sizeof(ARBITRARY_OVERWRITE_STRUCT));

    DbgPrint("[-] Before SetSave: %d\r\n", NtStatus);
    SetSavedData(&overwriteStruct);
    DbgPrint("[-] After SetSave: %d\r\n", NtStatus);
  } 
  __except(ExceptionFilter())
  {
    NtStatus = GetExceptionCode();
    DbgPrint("[!!] Exception Triggered: Handler body: Exception Code: %d\r\n", NtStatus);   
  }
    
  return NtStatus;                                      
} 



NTSTATUS     DvwdHandleIoctlStore(PIRP Irp, PIO_STACK_LOCATION pIoStackIrp)
{
  PCHAR pInputBuffer;
  UINT32 pInputLen;
  NTSTATUS NtStatus = STATUS_UNSUCCESSFUL;

  PAGED_CODE();
  pInputBuffer = pIoStackIrp->Parameters.DeviceIoControl.Type3InputBuffer;

  if(pInputBuffer)
    NtStatus = TriggerStore(pInputBuffer);

  return NtStatus;
}

