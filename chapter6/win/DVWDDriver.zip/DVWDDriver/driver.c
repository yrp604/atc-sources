#include <ntifs.h>
#include <ntstrsafe.h>
#include "dvwd.h"

#pragma warning(disable:4116)

#pragma alloc_text(INIT, DriverEntry)
#pragma alloc_text(PAGE, DvwdCreate) 
#pragma alloc_text(PAGE, DvwdClose) 
#pragma alloc_text(PAGE, DvwdIoControl) 
#pragma alloc_text(PAGE, DvwdNoFunction)
#pragma alloc_text(PAGE, DvwdUnload)


VOID DvwdUnload(PDRIVER_OBJECT  DriverObject)
{  	  
  UNICODE_STRING usDosDeviceName; 
  PAGED_CODE();    
  RtlInitUnicodeString(&usDosDeviceName, L"\\DosDevices\\DVWD");
  IoDeleteSymbolicLink(&usDosDeviceName);
  IoDeleteDevice(DriverObject->DeviceObject);
  DbgPrint("[-] Driver Unloaded\r\n");
}


NTSTATUS DvwdCreate(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
  PAGED_CODE(); 
  DbgPrint("[-] Device Created\r\n");
  return STATUS_SUCCESS;
}


NTSTATUS DvwdClose(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
  PAGED_CODE(); 
  DbgPrint("[-] Device Closed\r\n");
  return STATUS_SUCCESS;
}

NTSTATUS DvwdNoFunction(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
  NTSTATUS NtStatus = STATUS_NOT_SUPPORTED;
  PAGED_CODE(); 
  return NtStatus;
}

NTSTATUS DvwdIoControl(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
  NTSTATUS NtStatus = STATUS_NOT_SUPPORTED;
  PIO_STACK_LOCATION pIoStackIrp = NULL;
  PAGED_CODE();
  pIoStackIrp = IoGetCurrentIrpStackLocation(Irp);  

  DbgPrint("[-] Calling Ioctl DVWD_***\r\n");

  if(pIoStackIrp)
  {
      switch(pIoStackIrp->Parameters.DeviceIoControl.IoControlCode)
      {
        case DEVICEIO_DVWD_STACKOVERFLOW:
          DbgPrint("[-] Calling Ioctl DVWD_STACKOVERFLOW\r\n");
          NtStatus = DvwdHandleIoctlStackOverflow(Irp, pIoStackIrp);
          break;
		    
        case DEVICEIO_DVWD_OVERWRITE:
          DbgPrint("[-] Calling Ioctl DVWD_OVERWRITE\r\n");
          NtStatus = DvwdHandleIoctlOverwrite(Irp, pIoStackIrp);
	  break;

        case DEVICEIO_DVWD_STORE:
          DbgPrint("[-] Calling Ioctl DVWD_STORE\r\n");
          NtStatus = DvwdHandleIoctlStore(Irp, pIoStackIrp);
          DbgPrint("[-] Return: NtStatus: %d\r\n", NtStatus);
          break;
      }
  }

  Irp->IoStatus.Status = NtStatus;
  Irp->IoStatus.Information = 0;

  IoCompleteRequest(Irp, IO_NO_INCREMENT);
  return NtStatus;
}


NTSTATUS DriverEntry(PDRIVER_OBJECT  pDriverObject, PUNICODE_STRING  pRegistryPath)
{
  PDEVICE_OBJECT pDeviceObject; 
  NTSTATUS NtStatus = STATUS_SUCCESS;
  UNICODE_STRING usDriverName, usDosDeviceName;
  UINT32 i;

  PAGED_CODE();
  RtlInitUnicodeString(&usDriverName, L"\\Device\\DVWD");
  RtlInitUnicodeString(&usDosDeviceName, L"\\DosDevices\\DVWD"); 
  NtStatus = IoCreateDevice(pDriverObject, 0, &usDriverName, FILE_DEVICE_UNKNOWN, FILE_DEVICE_SECURE_OPEN, FALSE, &pDeviceObject);

  if(NtStatus != STATUS_SUCCESS)
  {
    DbgPrint("[-] Error Initializing DVWD\r\n");
    return NtStatus;
  }
    
  
  for(i = 0; i < IRP_MJ_MAXIMUM_FUNCTION; i++)
    pDriverObject->MajorFunction[i] = DvwdNoFunction;
    
  pDriverObject->MajorFunction[IRP_MJ_CREATE]        = DvwdCreate;
  pDriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL]    = DvwdIoControl;
  pDriverObject->MajorFunction[IRP_MJ_CLOSE]             = DvwdClose;

  pDriverObject->DriverUnload =  DvwdUnload;
  pDeviceObject->Flags &= (~DO_DEVICE_INITIALIZING);
  IoCreateSymbolicLink(&usDosDeviceName, &usDriverName);

  DbgPrint("[-] Driver Loaded\r\n");

  return NtStatus;
}